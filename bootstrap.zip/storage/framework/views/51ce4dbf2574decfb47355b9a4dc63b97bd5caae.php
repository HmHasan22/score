<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-10">
                <?php if(Session::has('success')): ?>
                    <div class="alert alert-success my-3">
                        <?php echo e(session('success')); ?>

                    </div>
                <?php endif; ?>
                <div class="card">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <div>League</div>
                        <div>
                            <a href="<?php echo e(route('add-league')); ?>" class="btn btn-primary">+ Add New</a>
                        </div>
                    </div>
                    <div class="card-body">
                        <?php if(count($data) > 0): ?>
                            <table class="table">
                                <thead>
                                    <th>SL</th>
                                    <th>League</th>
                                    <th>Action</th>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td width="10%"><?php echo e($loop->iteration); ?></td>
                                            <td width="70%"><?php echo e($value->name); ?></td>
                                            <td width="20%">
                                                <a href="<?php echo e(route('edit-league', $value->id)); ?>"
                                                    class="btn btn-success">Edit</a>
                                                <a href="<?php echo e(route('delete-league', $value->id)); ?>"
                                                    class="btn btn-danger">Delete</a>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        <?php else: ?>
                            <h2 class="text-center text-danger">No Data Found</h2>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\score\resources\views/league/index.blade.php ENDPATH**/ ?>