<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-10">
                <?php if(Session::has('success')): ?>
                    <div class="alert alert-success my-3">
                        <?php echo e(session('success')); ?>

                    </div>
                <?php endif; ?>
                <div class="card">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <div>
                            <?php echo e(__('Dashboard')); ?></div>
                        <a href="<?php echo e(route('result.create')); ?>" class="btn btn-primary">+ Add New</a>
                    </div>
                    <div class="card-body">
                        
                        <?php if(count($data) > 0): ?>
                            <table class="table">
                                <thead>
                                    <th>SL</th>
                                    <th>League</th>
                                    <th>Home Team</th>
                                    <th>Away Team</th>
                                    <th>Result One</th>
                                    <th>Result Two</th>
                                    <th>Action</th>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        
                                        <tr>
                                            <td><?php echo e($loop->iteration); ?></td>
                                            <td><?php echo e($value->league->name); ?></td>
                                            <td><?php echo e($value->home_team); ?></td>
                                            <td><?php echo e($value->away_team); ?></td>
                                            <td><?php echo e($value->result_one); ?></td>
                                            <td><?php echo e($value->result_two); ?></td>
                                            <td>
                                                <a href="<?php echo e(route('result.edit', $value->id)); ?>"
                                                    class="btn btn-success">Edit</a>
                                                <a href="<?php echo e(route('result.delete', $value->id)); ?>"
                                                    class="btn btn-danger">Delete</a>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        <?php else: ?>
                            <h2 class="text-center text-danger">No Data Found</h2>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\score_api\resources\views/result/index.blade.php ENDPATH**/ ?>