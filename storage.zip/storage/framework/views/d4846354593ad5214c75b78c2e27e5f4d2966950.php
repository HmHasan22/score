<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-6">
                <?php if(Session::has('success')): ?>
                    <div class="alert alert-success my-3">
                        <?php echo e(session('success')); ?>

                    </div>
                <?php endif; ?>
                <div class="card">
                    <div class="card-header">
                        <div class="card-title">
                            <div class="">Select Category</div>
                        </div>
                    </div>
                    <div class="card-body">
                        <form action="<?php echo e(route('qualification')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <select class="form-control" name="qualifications[]" id="select2-dropdown" multiple="multiple">
                                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($item); ?>"><?php echo e($item); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            </select>
                            <div class="mt-3">
                                <button class="btn btn-primary" type="submit">Submit</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script>
        $(document).ready(function() {
            $('#select2-dropdown').select2({
                placeholder: 'Select Option',
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\score_api\resources\views/score/score.blade.php ENDPATH**/ ?>